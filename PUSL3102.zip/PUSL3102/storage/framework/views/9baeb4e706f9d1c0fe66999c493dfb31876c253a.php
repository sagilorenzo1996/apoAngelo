<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <title>Laravel</title>
    </head>
    <body>
      <h1 style="text-align:center">Tracking System</h1>
      <div class="row">
        <div class="col-sm-3">
        </div>
        <div class="col-sm-6">
          <form class="" action="" method="post" id="managerLoginForm">
            <div class="form-group">
                <label for="managerId">Manager Id</label>
                <input type="text" class="form-control" id="managerId" placeholder="Enter manager id">
              </div>
              <div class="form-group">
                <label for="managerPassword">Password</label>
                <input type="password" class="form-control" id="managerPassword" placeholder="Password">
              </div>
              <small id="managerLoginError"></small><br>
              <button type="submit" class="btn btn-primary">Submit</button>
          </form>
          <script type="text/javascript">
            $(document).ready(function(){
              $('#managerLoginForm').on('submit',function(e){
                e.preventDefault();
                $.post('http://localhost:8000/api/managers/login',
                {
                  id: $('#managerId').val(),
                  password: $('#managerPassword').val()
                },function(data,status) {
                  if (data=="success") {
                    window.location.href = "/manager/"+$('#managerId').val();
                  }
                  else {
                    $('#managerLoginError').html("Login Error");
                  }
                  console.log(data + "this"+status)
                });
              });
            })
          </script>
        </div>
        <div class="col-sm-3">
        </div>
      </div>
      <br><br>
      <div class="row">
        <div class="col-sm-3">
        </div>
        <div class="col-sm-6">
          <form class="" action="" method="post" id="developerLoginForm">
            <div class="form-group">
                <label for="developerId">Developer Id</label>
                <input type="text" class="form-control" id="developerId" placeholder="Enter developer id">
              </div>
              <div class="form-group">
                <label for="developerPassword">Password</label>
                <input type="password" class="form-control" id="developerPassword" placeholder="Password">
              </div>
              <small id="developerLoginError"></small><br>
              <button type="submit" class="btn btn-primary">Submit</button>
          </form>
          <script type="text/javascript">
            $(document).ready(function(){
              $('#developerLoginForm').on('submit',function(e){
                e.preventDefault();
                $.post('http://localhost:8000/api/developers/login',
                {
                  id: $('#developerId').val(),
                  password: $('#developerPassword').val()
                },function(data,status) {
                  if (data=="success") {
                    window.location.href = "/developer/"+$('#developerId').val();
                  }
                  else {
                    $('#developerLoginError').html("Login Error");
                  }
                  console.log(data + "this"+status)
                });
              });
            })
          </script>
        </div>
        <div class="col-sm-3">
        </div>
      </div>
    </body>
</html>
